ENGLISH FLASHCARDS V7 — ĐỒNG BỘ MÁY TÍNH VÀ IPHONE
==================================================

Bản này giữ các tính năng từ v6 và thêm đăng nhập/đồng bộ đám mây qua Supabase.
Dữ liệu vẫn lưu cục bộ; khi đăng nhập, dữ liệu được tải lên/tải xuống tự động.
Các thiết bị đang đăng nhập kiểm tra dữ liệu mới khoảng mỗi 10 giây. Nếu cùng sửa một lúc,
thay đổi đồng bộ sau cùng có thể ghi đè thay đổi trước đó, vì vậy tránh chỉnh sửa đồng thời.

PHẦN A — TẠO DỊCH VỤ ĐỒNG BỘ MIỄN PHÍ
------------------------------------
1. Mở https://supabase.com/ và tạo tài khoản miễn phí.
2. Tạo một project mới. Đặt tên tùy ý, tạo mật khẩu database và chọn khu vực gần Việt Nam
   nếu có. Chờ project hoàn tất khởi tạo.
3. Trong project, mở SQL Editor, tạo query mới, dán và chạy toàn bộ SQL dưới đây:

create table if not exists public.flashcard_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.flashcard_data enable row level security;

drop policy if exists "Users can read their own flashcards" on public.flashcard_data;
create policy "Users can read their own flashcards"
  on public.flashcard_data for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "Users can insert their own flashcards" on public.flashcard_data;
create policy "Users can insert their own flashcards"
  on public.flashcard_data for insert to authenticated
  with check ((select auth.uid()) = user_id);

drop policy if exists "Users can update their own flashcards" on public.flashcard_data;
create policy "Users can update their own flashcards"
  on public.flashcard_data for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

4. Lấy thông tin kết nối của project:
   - Project URL
   - Publishable key (hoặc anon/public key ở giao diện cũ)
   Có thể nằm trong Project Settings → API / API Keys. Chỉ dùng publishable/anon key ở trình duyệt.
   TUYỆT ĐỐI KHÔNG đưa service_role key hoặc secret key vào file web.

PHẦN B — ĐIỀN THÔNG TIN VÀO FILE
--------------------------------
1. Mở index.html bằng trình soạn thảo văn bản (ví dụ VS Code hoặc Notepad).
2. Gần đầu phần JavaScript, tìm hai dòng:
   const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
   const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
3. Thay YOUR_SUPABASE_PROJECT_URL bằng Project URL, và YOUR_SUPABASE_ANON_KEY bằng
   publishable/anon key của project, giữ nguyên dấu ngoặc kép.
4. Lưu file. Đừng chia sẻ file đã cấu hình nếu không muốn công khai Project URL/key công khai.
   Publishable/anon key vốn được thiết kế để dùng phía trình duyệt; bảo vệ dữ liệu bằng RLS.

PHẦN C — ĐƯA WEB LÊN INTERNET MIỄN PHÍ BẰNG GITHUB PAGES
---------------------------------------------------------
Web cần có địa chỉ HTTPS để dùng ổn định trên iPhone; đừng chỉ mở file HTML cục bộ.
1. Tạo tài khoản tại https://github.com/ nếu chưa có.
2. Tạo repository mới, ví dụ english-flashcards (có thể để Public nếu muốn dùng GitHub Pages miễn phí).
3. Tải index.html đã cấu hình và README.txt lên repository; file index.html phải ở thư mục gốc.
4. Vào repository → Settings → Pages.
5. Trong Build and deployment, chọn Deploy from a branch; chọn branch main và folder /(root), rồi Save.
6. Chờ GitHub Pages xuất bản trang. Địa chỉ thường có dạng
   https://TEN-TAI-KHOAN.github.io/english-flashcards/
   Mở đúng địa chỉ do GitHub Pages hiển thị.

PHẦN D — CHUYỂN DỮ LIỆU VÀ DÙNG TRÊN HAI THIẾT BỊ
--------------------------------------------------
1. Trước hết mở web trên MÁY TÍNH, dùng nút “⬇ Sao lưu” để tải file JSON dự phòng.
2. Trên máy tính, nhập email và mật khẩu ở mục “Đồng bộ máy tính ↔ iPhone”, nhấn “Tạo tài khoản”.
   Nếu Supabase yêu cầu xác nhận email, mở email xác nhận rồi quay lại trang và đăng nhập.
3. Khi tài khoản mới chưa có dữ liệu đám mây, ứng dụng sẽ tải dữ liệu hiện có trên máy tính lên.
   Đợi dòng trạng thái báo đồng bộ thành công.
4. Trên iPhone, mở cùng địa chỉ GitHub Pages bằng Safari. Đăng nhập bằng đúng email/mật khẩu đó.
   Nếu đám mây đã có dữ liệu, ứng dụng sẽ tải dữ liệu đám mây về điện thoại.
5. Từ đó, khi thêm/sửa/xóa thẻ hoặc nhóm, ứng dụng sẽ tự đồng bộ. Có thể nhấn “Đồng bộ ngay”.
6. Giữ file JSON sao lưu định kỳ. Không bấm “Tạo tài khoản” lần nữa cho tài khoản đã có; hãy đăng nhập.

LƯU Ý QUAN TRỌNG
----------------
- Lần đầu hãy đăng nhập trên máy tính trước để tải bộ từ vựng hiện có lên đám mây, rồi mới đăng nhập
  trên iPhone. Khi đám mây đã có dữ liệu, đăng nhập sẽ tải dữ liệu đám mây xuống thiết bị đó.
- Bản hiện tại đồng bộ toàn bộ bộ dữ liệu của tài khoản. Nếu hai thiết bị cùng sửa đúng một lúc,
  thay đổi mới nhất có thể thay thế thay đổi còn lại. Tránh chỉnh sửa đồng thời và sao lưu JSON.
- Không chia sẻ mật khẩu tài khoản. Chính sách RLS trong SQL giới hạn mỗi tài khoản chỉ đọc/ghi dữ liệu
  của chính tài khoản đó.
- Nếu hiện “Chưa cấu hình Supabase”, hai dòng URL/key chưa được điền đúng hoặc chưa tải bản đã sửa lên.
- Nếu báo lỗi bảng/quyền, kiểm tra đã chạy SQL đầy đủ và đăng nhập bằng tài khoản đã xác nhận email nếu cần.
- Gói miễn phí của nhà cung cấp có giới hạn và điều khoản có thể thay đổi; kiểm tra bảng giá hiện hành.
